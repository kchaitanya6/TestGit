const people = [
    {
        name: 'Dexter',
        occupation: 'Engineer'
    },
    {
        name: 'Tom',
        occupation: 'Doctor'
    },
    {
        name: 'Rob',
        occupation: 'Cop'
    },
    {
        name: 'Tek',
        occupation: 'Engineer'
    },

];
function isEngineer(person) {
    return person.occupation === 'Engineer';
}
console.log(people.findIndex(isEngineer)); 
//console.log(people[people.findIndex(isEngineer)]); //to access object(element)
//console.log(people.reverse().find(isEngineer).name)