// Map 
//walmart store example
const products = [
    {'name': 'tires', 'price':50.99, 'rating':4.1},
    {'name': 'brakepad', 'price':30.99, 'rating':3.2},
    {'name': 'rooter', 'price':25.99, 'rating':2.7},
];

var names = products.map(p => p.name);
console.log(names);

//get an array of boolean value
var results = products.map(p =>(p.rating > 4));
console.log(results);
