// Map 
//walmart store example
const products = [
    {'name': 'tires', 'price':50.99, 'rating':4.1},
    {'name': 'brakepad', 'price':30.99, 'rating':3.2},
    {'name': 'rooter', 'price':4.99, 'rating':2.7},
];
var expensive = x => x['price'] > 5;
var expensive_products = products.filter(expensive);
console.log('expensive items:' , expensive_products);

//var query = products.filter(expensive).map(x => x.rating);
//onsole.log(query);