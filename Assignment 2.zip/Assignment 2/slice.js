var array = ["A", "B", "c", "D"];
console.log(array.slice(0,2));
console.log(array);

var fruits = ["Banana", "Orange", "Lemon", "Apple", "Mango"];
var citrus = fruits.slice(1, 3);
console.log(citrus);