//reduce()
// sum values of array;
/*myArray = [1,2,3,4];
output = myArray.reduce((acc, val, i, arr) =>
{
    console.log(
        'acc:', acc,
        'val:', val,
        'index:', i,
        'arr:', arr);
        return acc + val;
}, 100);
console.log('output:', output);
*/

//flatten array of arrays
myData = [[10, 3], [4, 5, 7], [3]];
output = myData.reduce((acc, val) => {
    rturn acc.concat(val);
}, []);

console.log(output);

